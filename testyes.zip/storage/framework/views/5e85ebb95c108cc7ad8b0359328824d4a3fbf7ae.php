<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
          *{
	margin: 0;
	padding: 0;
	font-family: 'Open Sans', sans-serif;
}

body{
	background: url(https://res.cloudinary.com/dejzo3x6l/image/upload/v1462601848/login%20page%20design/material-design-1080p-wallpaper_1.jpg) no-repeat center;
    /* background: url(https://coesenegal.com/wp-content/uploads/2019/09/artoff2572-1.jpg) no-repeat center; */
	background-attachment: fixed;
	background-size: cover;
    
}

.container{
	width: 500px;
	height: 400px;
	margin: 0px auto;
	margin-top: 20px;
	text-align: center;
	background-color: rgba(95, 158, 160, 0.43);
}

.container img{
	width: 120px;
	height: 120px;
	margin-top:-50px;
	margin-bottom: 50px;
}

input[type="text"],input[type="password"]{
	width: 250px;
	height: 30px;
	margin-bottom: 30px;
	padding-left: 30px;
	font-size: 17px;
}

.input_box::before{
	content:url(https://res.cloudinary.com/dejzo3x6l/image/upload/v1462601843/login%20page%20design/user.png);
	position: absolute;
	padding: 3.2px;
	background-color: rgba(219, 116, 40, 0.33);
}

.input_box:nth-child(3)::before{
	content:url(https://res.cloudinary.com/dejzo3x6l/image/upload/v1462601842/login%20page%20design/lock.png);
}
.submit_btn{
	background-color:rgb(214, 119, 49);
	font-size: 20px;
	padding:10px 30px;
	border: none;
	letter-spacing: 2px;
	transition: background-color .2s;
	margin-bottom: 10px;
}
.submit_btn:hover{
	background-color:rgb(247, 136, 55);
	cursor: pointer;
}

a.for_pass{
	color: #d1cfcf;
}
a.for_pass:hover{
	color:white;
}
</style>
</head>
<body>
<div style="
 margin-top:20px;

 position : relative;
">
   <img src="logo UCAD png.png" alt="logo UCAD" width="120px" height="110px" >
</div>

<div class="container">
		<form>
			<img src="https://res.cloudinary.com/dejzo3x6l/image/upload/v1462601844/login%20page%20design/3.png" alt="Profile-pic">
			<div class="">
                <b style="color:white;font-size:30px">Gestion de Cahier de texte</b>
            </div><br>
            <div class="input_box">
				<input type="text" name="username" placeholder="Nom d'utilisateur">
			</div>
			<div class="input_box">
				<input type="password" name="password" placeholder="Mot de passe">
			</div>
			<input type="submit" name="submit" value="SE CONNECTER" class="submit_btn">
			<br><a href="#" class="for_pass">Mot de passe oublié ?</a>
		</form>
	</div>
    <script>
    
    </script>
</body>
</html><?php /**PATH C:\laragon\www\test\resources\views/welcome.blade.php ENDPATH**/ ?>